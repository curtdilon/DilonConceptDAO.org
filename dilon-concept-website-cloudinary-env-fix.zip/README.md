# Dilon Concept Website

This repository contains the official website for the Dilon Concept Foundation, presenting our vision for societal restructuring based on resource rights and management.

## About the Dilon Concept

The Dilon Concept proposes a radical societal restructuring based on a resource-based economy. Each citizen inherently owns a share of national resources managed via a technological platform called Democracy 2.0, promoting equitable distribution and preventing corruption. Leadership, known as "Captain Dilons," is meritocratic, determined by resource management skills developed at Dilon Schools, emphasizing practical, self-sufficient living.

## Website Structure

- `index.html` - Main landing page
- `assets/` - Contains all CSS, JavaScript, and image files
- `pages/` - Individual pages for different sections of the website
- `includes/` - Reusable HTML components

## Key Features

- Information about the Dilon Concept philosophy and components
- Integration with Dilonland DAO (https://dilonland.org)
- Fundraising page with GoFundMe campaign integration
- Volunteer opportunities with free Dilonland DAO citizenship offers
- Blog section for updates on Dilon Concept development

## Deployment

This website is designed to be deployed on GitHub Pages or any static site hosting service. A netlify.toml file is included for easy deployment to Netlify.

## Contributing

We welcome contributions to improve the website. Please submit pull requests for any enhancements or bug fixes.

## License

© 2025 Dilon Concept Foundation. All rights reserved.
